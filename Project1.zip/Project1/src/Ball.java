public class Ball {
    double diameter;
    double volume;

    public Ball(double diameter, double volume) {
        this.diameter = diameter;
        this.volume = volume;
    }

    public double getDiameter() {
        return diameter;
    }

    public double getVolume() {
        return volume;
    }
}
